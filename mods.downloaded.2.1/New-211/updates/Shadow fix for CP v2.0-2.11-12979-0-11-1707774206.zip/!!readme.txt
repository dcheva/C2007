Unpack and copy the INI to Cyberpunk 2077\engine\config\platform\pc
